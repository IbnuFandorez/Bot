// Buat Lu Yang Jual Sc Ini Gw Tonjok 



const fs = require('fs')
const chalk = require('chalk')

global.gr = 'https://chat.whatsapp.com/G1JH8Q2AjdVFaptNYBHo9i'
global.ig = 'https://instagram/@' // ubah aja
global.ofc = 'https://chat.whatsapp.com/G1JH8Q2AjdVFaptNYBHo9i'
global.okta = 'https://taaofc-panel.my.id'
global.gh = 'https://github.com/chataofc'
global.saluran = 'https://chat.whatsapp.com/G1JH8Q2AjdVFaptNYBHo9i'
global.email = '-@gmail.com' //serah
global.region = 'indonesia' // serah
global.dana = '-'
global.gopay = '-'
global.pulsa = '-'
//—————「 Set Nama Own & Bot 」—————//
global.ownername = 'yassxofc' //ubah jadi nama mu, note tanda ' gausah di hapus!
//=================================================//
global.owner = ['-'] // ubah aja pake nomor lu
global.premium = ['-']
//==========================BY Hw Mods=======================//
global.lolkey = 'a8e86232771f9bc1826742c1'
global.zenz = 'zenzkey_41b4fe7a5d' // https://api.zahwazein.xyz
global.keyopenai = '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'
//====================BY Hw Mods=============================//
global.botname = 'yass🍁' //ubah jadi nama bot mu, note tanda ' gausah di hapus!
global.packname = 'yass' // ubah aja ini nama sticker
global.ta = '•' //cuma simbol
global.author = 'yassxofc🍁' // ubah aja ini nama sticker
global.prefa = ['','!','.',',','🐤','🗿']
global.sessionName = 'oka' //Gausah Juga
global.sp = '⭔' // Gausah Juga
global.wlcm = []
global.wlcmm = []
global.anticall = true
//=================================================//


//imgnya disini
global.thum = fs.readFileSync("./baseoka/image/thum.jpeg") 
global.good = fs.readFileSync("./baseoka/image/good.jpeg") 
global.vidmenu = fs.readFileSync("./baseoka/video/zoro.mp4")

global.mess = {
    done: '𝐃𝐨𝐧𝐞 𝐊𝐚𝐤 ',
    admin: '𝐅𝐢𝐭𝐮𝐫 𝐢𝐧𝐢 𝐛𝐮𝐚𝐭 *𝐀𝐝𝐦𝐢𝐧 𝐆𝐫𝐨𝐮𝐩* 𝐤𝐚𝐤',
    botAdmin: '𝐏𝐞𝐫𝐢𝐧𝐭𝐚𝐡 𝐈𝐧𝐢 𝐇𝐚𝐧𝐲𝐚 𝐁𝐢𝐬𝐚 𝐃𝐢𝐠𝐮𝐧𝐚𝐤𝐚𝐧 𝐊𝐞𝐭𝐢𝐤𝐚 𝐁𝐨𝐭 𝐌𝐞𝐧𝐣𝐚𝐝𝐢 𝐀𝐝𝐦𝐢𝐧 𝐆𝐫𝐨𝐮𝐩 ',
    owner: '𝐅𝐢𝐭𝐮𝐫 𝐢𝐧𝐢 𝐛𝐮𝐚𝐭 *𝐨𝐰𝐧𝐞𝐫* 𝐤𝐚𝐤',
    group: '𝐅𝐢𝐭𝐮𝐫 𝐢𝐧𝐢 𝐛𝐮𝐚𝐭 *𝐆𝐫𝐨𝐮𝐩 𝐂𝐡𝐚𝐭* 𝐤𝐚𝐤',
    private: '𝐅𝐢𝐭𝐮𝐫 𝐢𝐧𝐢 𝐛𝐮𝐚𝐭 *𝐀𝐝𝐦𝐢𝐧 𝐆𝐫𝐨𝐮𝐩* 𝐤𝐚𝐤',
    wait: '𝐭𝐮𝐧𝐠𝐠𝐮 𝐬𝐞𝐛𝐞𝐧𝐭𝐚𝐫 𝐲𝐚 𝐤𝐚𝐤',
    endLimit: '𝐥𝐢𝐦𝐢𝐭 𝐤𝐚𝐦𝐮 𝐬𝐮𝐝𝐚𝐡 𝐡𝐚𝐛𝐢𝐬 𝐤𝐚𝐤, 𝐭𝐮𝐧𝐠𝐠𝐮 𝐣𝐚𝐦 𝟏𝟐 𝐦𝐚𝐥𝐚𝐦 𝐮𝐧𝐭𝐮𝐤 𝐫𝐞𝐬𝐞𝐭',
    error: '*𝐅𝐢𝐭𝐮𝐫 𝐬𝐞𝐝𝐚𝐧𝐠 𝐞𝐫𝐨𝐫 𝐤𝐚𝐤!!!*',
    prem : '𝐅𝐢𝐭𝐮𝐫 𝐢𝐧𝐢 𝐛𝐮𝐚𝐭 𝐦𝐞𝐦𝐛𝐞𝐫 𝐩𝐫𝐞𝐦𝐢𝐮𝐦'
}
//=================================================//
//Gausah Juga
global.limitawal = {
    premium: "Infinity",
    free: 100
}

//rpg
global.buruan = {
   ikan: 5,
   ayam: 5,
   kelinci: 5,
   domba: 5,
   sapi: 5,
   gajah: 5
}
global.rpg = {
   darahawal: 100,
   besiawal: 5,
   goldawal: 1,
   emeraldawal: 1,
   umpanawal: 1,
   potionawal: 1
}
//=================================================//
let file = require.resolve(__filename)
fs.watchFile(file, () => {
	fs.unwatchFile(file)
	console.log(chalk.redBright(`Update'${__filename}'`))
	delete require.cache[file]
	require(file)
})